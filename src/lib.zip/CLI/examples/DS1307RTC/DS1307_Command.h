/*
   DS1307_Command.cpp - CLI library for Arduino/ESP8266 - DS1307 Command definitions

   Version 1.0, latest version, documentation and bugtracker available at:
                https://gitlab.lindenaar.net/arduino/CLI

   Copyright (c) 2019 Frederik Lindenaar

   This library is free software: you can redistribute it and/or modify it under
   the terms of version 3 of the GNU General Public License as published by the
   Free Software Foundation, or (at your option) a later version of the license.

   This code is distributed in the hope that it will be useful but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
   A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along with
   this program.  If not, visit <http://www.gnu.org/licenses/> to download it.
*/

#include <CLI.h>

class DS1307_Command : public CLI_Command {     // Definition of ds1307 command
  public:
    DS1307_Command(CLI &cli);                   // Constructor, requires CLI
    bool setparams(const char *params);         // Parameter parser
    bool execute(CLI &cli);                     // Implementation of logic
};

