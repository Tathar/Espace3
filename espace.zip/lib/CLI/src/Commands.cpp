/*
 * CLI_Commands.cpp - CLI library for Arduino/ESP8266 and others general commands
 *
 * Version 1.0, latest version, documentation and bugtracker available at:
 *              https://gitlab.lindenaar.net/arduino/CLI
 *
 * Copyright (c) 2019 Frederik Lindenaar
 *
 * This library is free software: you can redistribute it and/or modify it under
 * the terms of version 3 of the GNU General Public License as published by the
 * Free Software Foundation, or (at your option) a later version of the license.
 *
 * This code is distributed in the hope that it will be useful but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, visit <http://www.gnu.org/licenses/> to download it.
 */

#include <CLI.h>
#include <avr/eeprom.h>

Help_Command::Help_Command(CLI & cli) :
  CLI_Command(cli, PSTR("help"), PSTR("Display command help"),
      PSTR("Usage: help [<command>]\n"
           "\tdisplays usage help for <command> or lists available commands\n"
           "\twhen called without parameters\n")), _cli(cli) { };

bool Help_Command::setparams(const char *params) {
  if (_cmd_list = !params) {
    _cmd_idx = 0;
    return true;
  } else {
    _cmd_idx = _cli.find_command(params, strlen(params));
    return _cmd_idx < _cli.command_count();
  }
}

bool Help_Command::execute(CLI &cli) {
  if(CLI_Command *cmd = cli.get_command(_cmd_idx)) {
    if (_cmd_list) {
      if (_cmd_idx == 0) cli.print_P(PSTR("Known Commands:\n"));
      _cmd_idx++;
      cli.printtab();
      if (cli.print_P(cmd->command) < 8) cli.printtab();
      cli.printtab();
      cli.print_P(cmd->description);
      cli.println();
      return true;
    } else {
        cli.print_P(cmd->description);
        cli.println();
        if (cmd->usagehelp) cli.print_P(cmd->usagehelp);
    }
  } else if (_cmd_list) {
    cli.print_P((_cmd_idx)
                ? PSTR("\nfor more information on a command use \"help <command>\"")
                : PSTR("No Commands"));
  }
  cli.println();
  return false;
}


EEPROM_Dump_Command::EEPROM_Dump_Command(CLI & cli) : CLI_Command(cli,
      PSTR("eeprom_dump"), PSTR("Show EEPROM contents in HEX and ASCII")) { };

bool EEPROM_Dump_Command::setparams(const char *params) {
  _offset = 0;
  return !params && E2END > 0;
}

bool EEPROM_Dump_Command::execute(CLI &cli) {
  if (_offset == 0) {
    cli.print_P(PSTR("EEPROM Size: "));
    cli.print(E2END + 1);
    cli.print_P(PSTR(" Bytes\n\n"));
  }
  uint8_t buffer[16];
  eeprom_read_block(&buffer, (void *)_offset, sizeof(buffer));
  cli.print_mem(_offset, buffer, sizeof(buffer));
  _offset += sizeof(buffer);
  return _offset <= E2END;
}


Reset_Command::Reset_Command(CLI & cli) : CLI_Command(cli,
      PSTR("reset"), PSTR("Restart microcontroller")) { };

void(* resetFunc) (void) = 0; //declare reset function @ address 0
bool Reset_Command::execute(CLI &cli) {
  if (_resetting == 2000) resetFunc();
  if (!_resetting) cli.print(PSTR("resetting...\n\n"));
  _resetting++;
  return true;
}

